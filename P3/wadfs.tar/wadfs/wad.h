//
//  wad.h
//  P3
//
//  Created by Harsh Patel on 3/16/19.
//  Copyright © 2019 Harsh Patel. All rights reserved.
//

#ifndef wad_h
#define wad_h
#include <string>
#include <stdio.h>
#include <vector>
#include <unistd.h>
#include <sstream>
#include <algorithm>
using namespace std;


class Wad{
    
    
public:
    static Wad* loadWad(const string &path);
    char* getMagic();
    bool isContent(const string &path);
    bool isDirectory(const string &path);
    int getSize(const string &path);
    int getContents(const string &path, char *buffer, int length, int offset = 0);
    int getDirectory(const string &path, vector<string> *directory);
    
    
private:
    
    int fd;
    char* allData;
    char* magic;
    int cCheck = 0;
    int getOffset =0;
    //    int getLength =0;
    int dirStart = 0;
    int dirContents = 0;
    int contentLocation =0;
    vector<pair<uint32_t, string> > files;
    vector<pair<uint32_t, string> > fileOffset;
    
    uint32_t descriptorsInWad;
    //names of files without _START
    vector<string> fileStructure;
    vector<pair<string, uint32_t> > nsEnds;
    
    
};

#endif /* wad_h */

