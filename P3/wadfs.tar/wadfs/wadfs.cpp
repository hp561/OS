#define FUSE_USE_VERSION 26

#include <fuse.h>
#include <string.h>
#include <errno.h>
#include "wad.cpp"

static Wad* wadObject;

static int getattr_callback(const char *path, struct stat *stbuf) {
  memset(stbuf, 0, sizeof(struct stat));

  if (wadObject->isDirectory(path)) {
    stbuf->st_mode = S_IFDIR | 0555;
    stbuf->st_nlink = 2;
    return 0;
  }

  if (wadObject->isContent(path)) {
    stbuf->st_mode = S_IFREG | 0444;
    stbuf->st_nlink = 1;
    stbuf->st_size = wadObject->getSize(path);
    return 0;
  }

  return -ENOENT;
}

static int readdir_callback(const char *path, void *buf, fuse_fill_dir_t filler,
    off_t offset, struct fuse_file_info *fi) {
  (void) offset;
  (void) fi;
   vector<string> directory;
  wadObject->getDirectory(path, &directory);


  filler(buf, ".", NULL, 0);
  filler(buf, "..", NULL, 0);

for (size_t i = 0; i != directory.size(); i++) {

  const char* filename = directory[i].c_str();
   filler(buf, filename, NULL, 0);
}

  return 0;
}

static int open_callback(const char *path, struct fuse_file_info *fi) {

    return 0;
}

static int read_callback(const char *path, char *buf, size_t size, off_t offset,
    struct fuse_file_info *fi) {
    
    if (wadObject->isContent(path)) {
        buf = new char[size];
	 return wadObject->getContents(path, buf, size, offset);
    }
   
   return -ENOENT;
}

static int release_callback (const char *path, struct fuse_file_info *){
    
    if(wadObject->isContent(path))
    return 0;
    
    return -ENOENT;
    
}

static int  releasedir_callback (const char *path, struct fuse_file_info *){
    
    if(wadObject->isDirectory(path))
        return 0;
    
    return -ENOENT;
    
}

static int opendir_callback (const char *path, struct fuse_file_info *){
    
    if(wadObject->isDirectory(path))
        return 0;
    
    return -ENOENT;
    
}


static struct fuse_operations fuse_example_operations;


// static struct fuse_operations fuse_example_operations = {
//   getattr : getattr_callback,
//   open : open_callback,
//   read : read_callback,
//   readdir : readdir_callback,
// };

// fuse_example_operations.open
int main(int argc, char *argv[])
{
    
    if (argc < 2)
    {
        cout << "No file specified. Exiting." << endl;
        exit(EXIT_SUCCESS);
    }
  fuse_example_operations.getattr = getattr_callback;
  fuse_example_operations.open = open_callback;
  fuse_example_operations.read = read_callback;
  fuse_example_operations.readdir = readdir_callback;
  fuse_example_operations.release = release_callback;
    fuse_example_operations.releasedir = releasedir_callback;
    fuse_example_operations.opendir = opendir_callback;


      wadObject = Wad::loadWad(argv[argc-2]);

      argv[argc-2] = argv[argc-1];
      argv[argc-1] = NULL;
    
    int fuse_stat = fuse_main(argc-1, argv, &fuse_example_operations,NULL);
    
    delete wadObject;

  return fuse_stat;
}
