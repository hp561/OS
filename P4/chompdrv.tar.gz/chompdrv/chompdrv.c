#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include <linux/uinput.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

void emit(int fd, int type, int code, int val);

int main(){
    libusb_device **devs; //used to get list of devices
    libusb_device_handle *dev_handle;
    libusb_context *ctx = NULL; //libusb session
    int retVal; //Return values
    ssize_t cnt; //Holding number of devices in list

    retVal = libusb_init(&ctx);
    if(retVal < 0){
        printf("Init Error\n");
        return -1;
    }

    cnt = libusb_get_device_list(ctx, &devs); //Get the list of devices
    if(cnt < 0) {
        printf("Get Device Error\n");
        return 1;
    }

    dev_handle = libusb_open_device_with_vid_pid(ctx, 0x9A7A, 0xBA17);
    if (dev_handle == NULL){
        printf("Cannot Open the Device");
        return 1;
    }

    retVal = libusb_claim_interface(dev_handle, 0); //Claims interface 0
    if (retVal < 0){
        printf("Cannot Claim Interface\n");
        return 1;
    }
    

    struct uinput_user_dev usetup;
    //uinput_setup usetup;
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);

    //Listeners for virtual device, enable device to pass key events
    ioctl(fd, UI_SET_ABSBIT, ABS_X);

    ioctl(fd, UI_SET_ABSBIT, ABS_Y);

    ioctl(fd, UI_SET_EVBIT, EV_KEY);

    ioctl(fd, UI_SET_EVBIT, EV_ABS);

    ioctl(fd, UI_SET_KEYBIT, BTN_JOYSTICK);

    //create struct and allocate memory for it
    memset(&usetup, 0, sizeof(usetup));

    usetup.id.bustype = BUS_USB;

    //setting vendor id
    usetup.id.vendor = 0x9A7A;
    //setting product id
    usetup.id.product = 0xBA17;

    usetup.absmin[ABS_X] = -1;
    usetup.absmax[ABS_X] = 1;
    usetup.absfuzz[ABS_X] = 0;
    usetup.absflat[ABS_X] = 0;

    usetup.absmin[ABS_Y] = -1;
    usetup.absmax[ABS_Y] = 1;
    usetup.absfuzz[ABS_Y] = 0;
    usetup.absflat[ABS_Y] = 0;

    snprintf(usetup.name, UINPUT_MAX_NAME_SIZE, "uinput old interface");

    write(fd, &usetup, sizeof(usetup)); 
    ioctl(fd, UI_DEV_CREATE); 

    int data;
    unsigned char bitShift;

    while(1){

        retVal = libusb_interrupt_transfer(dev_handle, (1 | LIBUSB_ENDPOINT_IN), &bitShift, 1, &data, 0);

        if (retVal != 0) {
          break;
        }
        // setting up js0 usb and writing to device in kernel space
        int button = (bitShift >> 4) & 0x01; //Button
        emit(fd, EV_KEY, BTN_JOYSTICK, button);
        emit(fd, EV_SYN, SYN_REPORT, 0);

        int xCoordinate = (bitShift >> 2);
        int yCoordinate = bitShift & 0x03;


        if (xCoordinate == 1 || xCoordinate == 5){
            emit(fd, EV_ABS,ABS_X, -1);
        }
        else if (xCoordinate == 3 || xCoordinate == 7){
            emit(fd, EV_ABS, ABS_X, 1);
        }
        else{
            emit(fd, EV_ABS, ABS_X, 0);
        }

        if(yCoordinate == 0){
            emit(fd, EV_ABS, ABS_Y, 0);
        }
        else if (yCoordinate == 1){
            emit(fd, EV_ABS, ABS_Y, 1);
        }
        else if (yCoordinate == 2){
            emit(fd, EV_ABS, ABS_Y, 0);
        }
        else if (yCoordinate == 3){
            emit(fd, EV_ABS, ABS_Y, -1);
        }

        emit(fd, EV_SYN, SYN_REPORT, 0);

        sleep(1);
    }

    retVal = libusb_release_interface(dev_handle,0);

    if(retVal != 0){return 1;}

    libusb_close(dev_handle); //closes the device
    libusb_exit(ctx); //exit the session
    ioctl(fd, UI_DEV_DESTROY); //destroy the device
    close(fd); //close file

    return 0;
}

void emit(int fd, int type, int code, int val){

    struct input_event ie;
    ie.type = type;
    ie.code = code;
    ie.value = val;

    write(fd, &ie, sizeof(ie));
}
