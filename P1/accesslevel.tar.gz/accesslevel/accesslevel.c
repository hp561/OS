#include <stdio.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>
#include "accesslevel.h"

int set_access_level (int pid, int new_level){
	return syscall(336, pid, new_level);
}

int get_access_level (int pid){
	return syscall(335, pid);
}

int* retrieve_set_access_params (int pid, int new_level){
	int *arr = malloc(4);
	arr[0] = 336;
	arr[1] = 2;
	arr[2] = pid;
	arr[3] = new_level;
	return arr;
}

int* retrieve_get_access_params (int pid){
	int *arr = malloc(3);
	arr[0] = 355;
	arr[1] = 1;
	arr[2] = pid;
	return arr;
}

int interpret_set_access_result (int ret_value){
	if(ret_value == -1)
	{
		return ret_value;
	}
	if(ret_value>=0)
	{
		return ret_value;
	}

	return -1;
}

int interpret_get_access_result (int ret_value){

	if(ret_value ==-1)
	{

	return ret_value;

	}
	if(ret_value>=0) {

	return ret_value;
	}
	return -1;
}

