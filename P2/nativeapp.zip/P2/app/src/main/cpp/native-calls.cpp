#include <jni.h>
#include <string>
#include <sstream>
#include <exception>
#include <stdexcept>
#include <iostream>
#include "MemoryManager.h"
#include <string>
#include <cstring>
#include <algorithm>

# define OUT_PATH "mnt/ubuntu/home/reptilian/logs/"

MemoryManager mem (1, bestFit);
int maxWOrds = 0;
// Provided example native call
extern "C"
JNIEXPORT jstring JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}


//done
extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_initMemoryManager(JNIEnv *env,jobject,jint maxAllocationSize){
    // TODO:
    // Function should initialize your Memory Manager object with the specified word size;
    maxWOrds = maxAllocationSize ;
    mem.initialize(maxAllocationSize);

}
//done
extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_deleteMemoryManager(JNIEnv *env,jobject){
    // TODO:
    // Function should release all resources held by the Memory Manager
    mem.shutdown();

}

extern "C"
JNIEXPORT jint JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_getFreeSize(JNIEnv *env,jobject){
    // TODO:
    // Function returns the word size of the free list

    int wordsFree = 0;

    uint16_t *bitM =(uint16_t*)mem.getList();
    for (int i = 2; i!=bitM[0]+1 ; i+=2) {

        if ((i+1) ==bitM[0]+1)
            break;
        wordsFree = wordsFree+bitM[i];

    }

    return wordsFree;


}
//done
extern "C"
JNIEXPORT jint JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_getUseSize(JNIEnv *env,jobject){
    // TODO:
    // Function returns the word size of the in use list


    int wordsFree = 0;

    uint16_t *bitM =(uint16_t*)mem.getList();
    for (int i = 2; i!=bitM[0]+1 ; i+=2) {

        if ((i+1) ==bitM[0]+1)
            break;
        wordsFree = wordsFree+bitM[i];

    }



    return (maxWOrds-wordsFree);
}

//ignore
extern "C"
JNIEXPORT jint JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_getFragSize(JNIEnv *env,jobject){
    // TODO:
    // Function returns the word size of the number of fragments within the Memory Manager
    return 0;
}

//done
extern "C"
JNIEXPORT jstring JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_allocateMemory(JNIEnv *env,jobject,jint size){
    // TODO:
    // Function allocates memory in the Memory Manager and returns the address of the starting block
    // If none is available, return "RIP"


    uint32_t* address = static_cast<uint32_t*>(mem.allocate(size));

    ostringstream get_the_address;
    get_the_address << address;
    std::string Saddress =  get_the_address.str();


    if(address!= nullptr) {




        return env->NewStringUTF(Saddress.c_str());
    }

    std::string addr = "RIP";

    return env->NewStringUTF(addr.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_freeMemory(JNIEnv *env,jobject, jstring addr){
    // TODO:
    // Function frees block at specified address within the Memory Manager



    mem.free(addr);
}
//done
extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_shutdown(JNIEnv *env,jobject){
    // TODO:
    // Function frees all in use memory from within the Memory Manager
    mem.shutdown();
}

//done
extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_setAlgorithm(JNIEnv *env,jobject, jint alg){
    // TODO:
    // Functions changes the internal allocation algorithm used within your Memory Manager
    // 1 denotes Best Fit, 2 denotes Worst fit

    if(alg == 1){

        mem.setAllocator(bestFit);
    }
    if (alg==2){

        mem.setAllocator(worstFit);

    }
}

//ignore this
extern "C"
JNIEXPORT void JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_writeLogs(JNIEnv *env,jobject){
    // TODO:
    // Use your POSIX calls to write logs to file at OUT_PATH that represent the holes in memory
}




